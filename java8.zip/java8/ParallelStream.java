package com.assignment.java8;
//11. wap to perform parrallel stream api to find the no.
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

public class ParallelStream {

	public static void main(String[] args)
	        throws IOException
	    {
	  
	        File fileName
	            = new File("D:\\amit\\java workspace\\Assignment java8\\src\\com\\assignment\\java8\\List_Textfile.txt");
	  
	        List<String> text
	            = Files.readAllLines(fileName.toPath());
	  
	        text.parallelStream().forEach(System.out::println);
	    }
}

package com.assignment.java8;
//5. WAP to find the maximum length of given string without using any length function use 
import java.util.Arrays;
import java.util.Scanner;

public class MaxLengthString {

public static void main(String args[]) {
		
		String str1;
	Scanner scanner =new Scanner(System.in);
 		System.out.println("Enter a String  ");
 		String str= scanner.next();
 		System.out.println(str.lastIndexOf(""));
		
		
		
	

}
            	public static int getLength(String str)
            	{
            	    int i=0;
            	    try{
            	    
            	    while(true)
            	    {
            	        str.charAt(i);
            	        i++;
            	    }
            	    }
            	    catch(IndexOutOfBoundsException e)
            	    
            	    {
            	     return i;   
            	    }
            	}

}

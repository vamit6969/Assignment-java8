package com.assignment.java8;

//10. WAP to create 10 objects of employee class, add all object to arraylist and from arraylist we 
//need to convert this to map and set using stream api.

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

public class ArrayListToMapSet {

	public static void main(String[] args)
	{

		
		List<Employee> lt = new ArrayList<>();

	
		lt.add(new Employee(1, "Amit"));
		lt.add(new Employee(2, "Amay"));
		lt.add(new Employee(3, "Pankaj"));
		lt.add(new Employee(4, "Avinash"));
		lt.add(new Employee(5, "Mayank"));
		lt.add(new Employee(6, "aman"));
		lt.add(new Employee(7, "Gracy"));
		lt.add(new Employee(8, "Jamunda"));
		lt.add(new Employee(9, "Sahil"));
		lt.add(new Employee(10, "Pranav"));

		

		
		LinkedHashMap<Integer, String>
			map = lt.stream()
					.collect(
						Collectors
							.toMap(
								Employee::getId,
								Employee::getName,
								(x, y)
									-> x + ", " + y,
									LinkedHashMap::new));

		
		map.forEach(
			(x, y) -> System.out.println(x + "=" + y));
	}
}
